using System;
using System.Collections.Generic;
using Sandbox.ModAPI;
using VRage.Game.ModAPI;
using VRageMath;
using Vgs.Core;
using Vgs.Game;
using Vgs.Model;

namespace Vgs.Ui
{
    /// <summary>
    /// Input: the four pointer modes (idle, bind, watch, menu), the pan and zoom, the drag,
    /// and the hit tests that decide what the pointer is over.
    ///
    /// A partial of <see cref="VgsEditorScreen"/>. The modes are mutually exclusive and each
    /// handler owns the pointer completely; geometry comes from <see cref="PortGeometry"/>.
    /// </summary>
    public sealed partial class VgsEditorScreen
    {
        // ------------------------------------------------------------------ input

        protected override void OnHandleInput()
        {
            try
            {
                // TryCursor reports in client-area coordinates only while this transform is
                // current, and the hit tests below assume exactly those units (ADR-0009).
                VgsScreenDraw.SyncScreenSpace();

                if (MyAPIGateway.Input == null) return;

                // The argument dialog is modal and owns both the keyboard and the pointer while
                // it is open (ADR-0050): typing must not reach the search field behind it, and a
                // click outside it must not pan or select. It is therefore the very first branch,
                // before the search field, which is otherwise always the keyboard target.
                //
                // The pointer is still resolved, because the dialog has fields and buttons to hit
                // — but a missing cursor is not an early return here: the dialog must keep taking
                // keys even when the pointer is outside the window, exactly as the search field
                // does.
                if (_paramForm != null)
                {
                    Vector2 dialogMouse;
                    _mouseValid = VgsScreenDraw.TryCursor(out dialogMouse);
                    _mouse = dialogMouse;

                    HandleParameterKeyboard();
                    if (_paramForm != null) HandleParameterDialogInput(dialogMouse);
                    return;
                }

                // Typing is handled before the pointer, and before the "no cursor" early return:
                // the search field is the editor's only keyboard target, and it must keep working
                // when the pointer happens to be outside the window.
                HandleSearchKeyboard();

                Vector2 mouse;
                _mouseValid = VgsScreenDraw.TryCursor(out mouse);
                if (!_mouseValid) return;

                _mouse = mouse;

                if (HandleCloseButton(mouse)) return;

                // The bottom bar's controls are hit-tested before every mode: they belong to the
                // chrome, and a click on the search field must not also pan the canvas or pick a
                // binding target.
                if (HandleBarInput(mouse)) return;

                if (_menuTarget != null) { HandleMenuInput(mouse); return; }
                if (_bindSource != null) { HandleBindInput(mouse); return; }
                if (_watchSource != null) { HandleWatchInput(mouse); return; }

                HandleCanvasInput(mouse);
            }
            catch (Exception e)
            {
                VgsLog.Throttled("screeninput", "input handling failed", e, 300);
            }
        }

        /// <summary>
        /// Feeds the typed characters, the editing keys and the clipboard shortcuts into the
        /// search field (ADR-0023, ADR-0024).
        ///
        /// <b>The field is always the keyboard target.</b> The editor has no other text input and
        /// no keyboard shortcut but Esc, so there is nothing to take focus from it and no focus
        /// ring to explain. A click on the canvas does not blur it, which is what makes "type
        /// anywhere to filter" work.
        ///
        /// <b>The character stream is per frame.</b> The game hands over the characters typed
        /// since the last input update and swaps its buffer, so reading
        /// <see cref="VRage.ModAPI.IMyInput.TextInput"/> once per frame consumes each character
        /// exactly once (verified by IL, see <c>docs/01-research/api-terminal-search.md</c>).
        ///
        /// <b>Order matters.</b> Control keys are resolved before the character stream, because
        /// Ctrl+C also produces a character (0x03) and Backspace produces 0x08: both would be
        /// dropped by the control-character filter anyway, but resolving the shortcut first is what
        /// makes the *one* intent produce the *one* effect. And the stream is consumed last and
        /// unconditionally — every character must be read out of the buffer each frame whether or
        /// not some other key was handled, or the game would carry it into the next frame.
        /// </summary>
        private void HandleSearchKeyboard()
        {
            VRage.ModAPI.IMyInput input = MyAPIGateway.Input;
            if (input == null) return;

            // While the modes popup is open it owns the keyboard: typing must not edit the query
            // behind it, and Ctrl+V must not paste into a field the player cannot see past the
            // menu. This follows the same rule the canvas already follows (ADR-0023 §4: nothing
            // behind the popup takes input) and the Esc order — each step cancels exactly what the
            // player started last, and the menu is what was started last.
            //
            // The character stream is still drained, and that is the whole reason this is a
            // branch and not an early return: an undrained character is carried into the next
            // frame, so it would appear in the field the moment the menu closed — the keystroke
            // would seem to arrive late rather than to be ignored.
            if (_modesMenuOpen)
            {
                VRage.Collections.ListReader<char> swallowed = input.TextInput;
                if (swallowed.Count > 0)
                {
                    VgsLog.Debug("modes menu swallowed " + swallowed.Count +
                                 " typed character(s)");
                }
                return;
            }

            bool control = input.IsAnyCtrlKeyPressed();
            bool shift = input.IsAnyShiftKeyPressed();

            // ---- clipboard ----
            if (control)
            {
                if (input.IsNewKeyPressed(VRage.Input.MyKeys.C)) CopySearchText(false);
                if (input.IsNewKeyPressed(VRage.Input.MyKeys.X)) CopySearchText(true);
                if (input.IsNewKeyPressed(VRage.Input.MyKeys.V)) PasteSearchText();
                if (input.IsNewKeyPressed(VRage.Input.MyKeys.A)) SelectAllSearchText();
            }

            // ---- caret movement and deletion ----
            //
            // Shift extends the selection, a bare arrow collapses it: the rule lives in
            // TextEditor.MoveHorizontal, so these four lines only carry the intent. The field
            // invalidates its cached layout and restarts the blink itself — that pairing is why
            // the field is a type and not four loose fields on this class.
            if (input.IsNewKeyPressed(VRage.Input.MyKeys.Left))
            {
                _searchField.MoveHorizontal(-1, shift, _screenFrame);
            }

            if (input.IsNewKeyPressed(VRage.Input.MyKeys.Right))
            {
                _searchField.MoveHorizontal(1, shift, _screenFrame);
            }

            if (input.IsNewKeyPressed(VRage.Input.MyKeys.Home))
            {
                _searchField.MoveTo(0, shift, _screenFrame);
            }

            if (input.IsNewKeyPressed(VRage.Input.MyKeys.End))
            {
                _searchField.MoveTo(_searchField.Text.Length, shift, _screenFrame);
            }

            if (input.IsNewKeyPressed(VRage.Input.MyKeys.Delete))
            {
                if (_searchField.DeleteForward(_screenFrame)) OnSearchTextChanged();
            }

            if (input.IsNewKeyPressed(VRage.Input.MyKeys.Back))
            {
                if (_searchField.Backspace(_screenFrame)) OnSearchTextChanged();
            }

            if (input.IsNewKeyPressed(VRage.Input.MyKeys.Enter))
            {
                JumpToFirstMatch();
            }

            // The stream is always drained, even when a shortcut above already acted on it.
            VRage.Collections.ListReader<char> typed = input.TextInput;
            for (int i = 0; i < typed.Count; i++)
            {
                AppendSearchChar(typed[i]);
            }
        }

        /// <summary>Selects the whole query (Ctrl+A).</summary>
        private void SelectAllSearchText()
        {
            _searchField.SelectAll(_screenFrame);
        }

        /// <summary>
        /// Click handling for the bottom bar: the modes button, its popup, and the search field
        /// with its clear button. Returns true when the click was consumed by the bar.
        /// </summary>
        private bool HandleBarInput(Vector2 mouse)
        {
            bool leftNew = MyAPIGateway.Input.IsNewLeftMousePressed();

            Vector2 buttonTopLeft, buttonSize;
            GetModesButtonRect(out buttonTopLeft, out buttonSize);
            _modesHot = PortGeometry.Contains(buttonTopLeft, buttonSize, mouse);

            // ---- modes popup (drawn above the button, so it is resolved first) ----
            if (_modesMenuOpen)
            {
                // The canvas and the search field are not reachable while the popup is up, so
                // every "pointer is over this" highlight is dropped here rather than left on from
                // before the menu opened: a card that kept its hover border behind an open menu
                // reads as a stuck control.
                ClearHoverHighlights();

                _modesRowHot = HitModesRow(mouse);

                if (leftNew)
                {
                    // The button toggles the popup even while it is open: that is what a menu
                    // button does everywhere else, and without this a second click on it would
                    // fall through to "close on any outside click" and look the same — until the
                    // pointer happens to be over the button and the menu seems to ignore it.
                    if (_modesHot)
                    {
                        _modesMenuOpen = false;
                        return true;
                    }

                    if (_modesRowHot >= 0)
                    {
                        ToggleModesRow(_modesRowHot);
                        return true;
                    }

                    Vector2 menuTopLeft, menuSize;
                    GetModesMenuRect(out menuTopLeft, out menuSize);

                    // A click inside the popup but not on its row is a miss on the popup, not a
                    // command: the menu stays open. A click anywhere else closes it.
                    if (PortGeometry.Contains(menuTopLeft, menuSize, mouse)) return true;

                    _modesMenuOpen = false;
                    return true;
                }

                return true;
            }

            _modesRowHot = -1;

            // ---- modes button ----
            if (leftNew && _modesHot)
            {
                _modesMenuOpen = true;
                return true;
            }

            // ---- search field ----
            Vector2 fieldTopLeft, fieldSize;
            GetSearchFieldRect(out fieldTopLeft, out fieldSize);
            _searchField.Hot = PortGeometry.Contains(fieldTopLeft, fieldSize, mouse);

            // The clear button exists only while there is something to clear, and it is
            // resolved before the field for the same reason the port's "x" is resolved before its
            // card: the smaller target on top of the bigger one has to win.
            Vector2 clearTopLeft, clearSize;
            _searchField.ClearHot = SearchHasText
                                    && TrySearchClearRect(out clearTopLeft, out clearSize)
                                    && PortGeometry.Contains(clearTopLeft, clearSize, mouse);

            if (leftNew && _searchField.ClearHot)
            {
                ClearSearch();
                return true;
            }

            // A click inside the field belongs to the field, never to the canvas underneath it.
            // It also decides where the caret goes, which is the one thing a click in a text field
            // is *for*: without this the field had no way to place the caret except by typing.
            if (leftNew && _searchField.Hot)
            {
                PlaceCaretAtPointer(mouse, fieldTopLeft);
                return true;
            }

            return false;
        }

        /// <summary>
        /// Puts the caret at the character boundary nearest the pointer, and drops any selection.
        ///
        /// The inverse of <see cref="SearchField.EnsureLayout"/>: it walks the character
        /// boundaries that layout already measured and picks the closest one. Walking measured
        /// boundaries rather than dividing by an average character width is what makes a click
        /// land between the two glyphs the player aimed at, whatever the font's spacing is.
        ///
        /// With Shift held it extends the selection instead, which is how a click completes a
        /// selection that was started by keyboard.
        /// </summary>
        private void PlaceCaretAtPointer(Vector2 mouse, Vector2 fieldTopLeft)
        {
            float textLeft = fieldTopLeft.X + VgsConstants.SearchFieldPadding;
            // A click anywhere in the field (including on the padding, or on the right half of the
            // space the "x" does not occupy) scrolls the text, so the pointer has to be converted
            // through the current scroll to reach a text coordinate.
            float targetX = mouse.X - textLeft + _searchField.ScrollX;

            _searchField.PlaceCaretAt(targetX, MyAPIGateway.Input.IsAnyShiftKeyPressed(),
                                      _screenFrame);
        }

        /// <summary>
        /// Switches the "show invisible" mode: rebuilds the graph, since whether a hidden block is
        /// part of the schema is decided while it is built (ADR-0023), and writes the new view so
        /// the mode survives closing the editor (ADR-0022).
        /// </summary>
        private void ToggleShowHidden()
        {
            _view.ShowHidden = !_view.ShowHidden;

            RebuildGraph();
            SaveView();

            VgsLog.Info("show invisible blocks: " + (_view.ShowHidden ? "on" : "off"));
        }

        /// <summary>
        /// Flips whether blocks standing on subgrids are part of the schema (ADR-0032).
        ///
        /// Rebuilds the graph for the same reason "show invisible" does: whether a node exists is
        /// decided while the graph is built. A draw-time filter would leave the edges of the
        /// hidden cards in place, and an edge to a card that is not painted is a line ending in
        /// nothing — worse than not drawing the line at all.
        /// </summary>
        private void ToggleShowSubgrids()
        {
            _view.ShowSubgrids = !_view.ShowSubgrids;

            RebuildGraph();
            SaveView();

            VgsLog.Info("show subgrid blocks: " + (_view.ShowSubgrids ? "on" : "off"));
        }

        /// <summary>
        /// Flips whether the frame around each grid's cards is drawn (ADR-0032).
        ///
        /// <b>No rebuild.</b> This changes nothing about the graph — only whether a border is
        /// painted — so it is free even on a large construct, and it cannot disturb a connection.
        /// The frames are recomputed by the draw pass's own layout call, which runs anyway.
        /// </summary>
        private void ToggleShowGridBorders()
        {
            _view.ShowGridBorders = !_view.ShowGridBorders;

            SaveView();

            VgsLog.Info("show grid borders: " + (_view.ShowGridBorders ? "on" : "off"));
        }

        /// <summary>
        /// Applies the toggle in the given modes-menu row. One place that maps a row index to an
        /// action, so the menu's drawing, its hit test and its behaviour cannot disagree about
        /// what a row means.
        /// </summary>
        private void ToggleModesRow(int index)
        {
            switch (index)
            {
                case 0: ToggleShowHidden(); return;
                case 1: ToggleShowSubgrids(); return;
                case 2: ToggleShowGridBorders(); return;
                case 3: ToggleShowConveyors(); return;
            }
        }

        /// <summary>
        /// Flips whether the conveyor network is drawn as pipes (ADR-0040).
        ///
        /// <b>Rebuilds the graph, like "show subgrids".</b> The links are derived from the grid's
        /// serialised conveyor lines, and that read is heavy enough that it is not paid for a
        /// picture nobody asked to see; whether the links exist is therefore decided while the
        /// graph is built. A draw-time filter would have bought a free toggle at the price of
        /// serialising every card-holding grid on every structural refresh.
        ///
        /// Nothing in the world changes: the pipes are derived, never written, so turning the
        /// network off cannot break a conveyor and turning it back on shows exactly the same
        /// network.
        /// </summary>
        private void ToggleShowConveyors()
        {
            _view.ShowConveyors = !_view.ShowConveyors;

            RebuildGraph();
            SaveView();

            VgsLog.Info("show conveyor network: " + (_view.ShowConveyors ? "on" : "off"));
        }

        /// <summary>
        /// Click handling for the self-drawn Close button. Returns true when the click was
        /// consumed, so it cannot also start a drag on the canvas underneath.
        /// </summary>
        private bool HandleCloseButton(Vector2 mouse)
        {
            Vector2 buttonTopLeft, buttonSize;
            GetCloseButtonRect(out buttonTopLeft, out buttonSize);

            _closeHot = PortGeometry.Contains(buttonTopLeft, buttonSize, mouse);

            if (!_closeHot || !MyAPIGateway.Input.IsNewLeftMousePressed()) return false;

            Close();
            return true;
        }

        /// <summary>
        /// Pans the canvas while <paramref name="buttonDown"/> is held over it. Returns true when
        /// this frame's pointer input belongs to the pan, so the caller must not also hover,
        /// select or click.
        ///
        /// One implementation for the three places that pan: the idle canvas, the bind gesture
        /// and the watch gesture. The gestures pan with the middle button only — their right
        /// button already means "cancel" — while the idle canvas pans with either, which is why
        /// the button state is a parameter rather than read here.
        ///
        /// The anchor survives a pointer that leaves the canvas while the button is held: the pan
        /// resumes from where the drag left it instead of jumping. Dropping it on every frame
        /// outside the canvas would make a drag that grazes the header twitch.
        /// </summary>
        private bool PanWhileHeld(bool buttonDown, Vector2 mouse, Vector2 canvasTopLeft,
                                  Vector2 canvasSize)
        {
            if (!buttonDown)
            {
                _panning = false;
                return false;
            }

            if (!PortGeometry.Contains(canvasTopLeft, canvasSize, mouse)) return false;

            if (!_panning)
            {
                _panning = true;
                _panAnchor = mouse;
                return true;
            }

            _view.Camera -= (mouse - _panAnchor) / _view.Zoom;
            _panAnchor = mouse;
            return true;
        }

        /// <summary>
        /// Middle-button pan, shared by the bind and the watch gestures: both keep the middle
        /// button free for panning while the pointer is busy picking a target.
        /// </summary>
        private bool PanWithMiddleButton(Vector2 mouse, Vector2 canvasTopLeft, Vector2 canvasSize)
        {
            return PanWhileHeld(MyAPIGateway.Input.IsMiddleMousePressed(),
                                mouse, canvasTopLeft, canvasSize);
        }

        /// <summary>
        /// Right click on a card opens the manual action menu (ADR-0041). Returns true when this
        /// frame's pointer input was consumed by such a click.
        ///
        /// <b>Why a press/release pair and not just the press.</b> The right button has panned the
        /// canvas since stage 1, and opening a menu on the press would take the pan away from
        /// every card — on a dense schema it would only work in the gaps between cards. So the
        /// press arms a candidate when it lands on a node, the pointer travelling farther than
        /// <see cref="VgsConstants.ClickSlopPixels"/> drops it (that is a pan), and the release
        /// turns what is left into a click. Nothing is armed mid-drag either: while a card or a
        /// group is being dragged, the right button belongs to the drag.
        ///
        /// <b>Ports count as their card.</b> The hit test is the ordinary node test, so a right
        /// click on a port bar opens the menu of the block the bar belongs to — the bar is part of
        /// that block's picture, not a separate thing to click.
        /// </summary>
        private bool HandleManualActionClick(Vector2 mouse, Vector2 canvasTopLeft, bool insideCanvas)
        {
            bool rightNew = MyAPIGateway.Input.IsNewRightMousePressed();
            bool rightDown = MyAPIGateway.Input.IsRightMousePressed();
            bool rightReleased = MyAPIGateway.Input.IsNewRightMouseReleased();

            if (rightNew)
            {
                _rightClickAnchor = mouse;
                _rightClickNode = insideCanvas && !_dragging
                    ? HitTest(ScreenToGraph(mouse, canvasTopLeft))
                    : null;

                // A press and its release can arrive in the same frame — the game reports both
                // flags at once when a frame is long enough. That is still a click, and an early
                // `return` here would throw it away without a trace (the candidate is cleared on
                // the next frame before any release is seen), so the frame falls through to the
                // release branch below with the slop trivially satisfied.
                if (!rightReleased) return false;
            }

            if (_rightClickNode == null) return false;

            // A drag that started after the press means the press belongs to the drag, not to a
            // click: the player grabbed a card with the left button and the right one was already
            // down. Dropped here rather than checked only at press time, because the order of the
            // two buttons is not ours to require.
            if (_dragging) { _rightClickNode = null; return false; }

            // The movement is re-checked here and not only in the held branch above: a frame that
            // comes after a long gap sees the button already up, so the last position the held
            // branch compared is not necessarily where the release happened.
            bool moved = PointerGesture.ExceedsClickSlop(mouse - _rightClickAnchor,
                                                         VgsScreenDraw.ClientWidth,
                                                         VgsScreenDraw.ClientHeight);

            if (rightDown)
            {
                if (moved) _rightClickNode = null;
                return false;
            }

            // The button is up. Clear the candidate even when no release event was seen (a frame
            // without focus can swallow it), so a stale card cannot be opened by the next press.
            Node target = _rightClickNode;
            _rightClickNode = null;

            if (!rightReleased || moved) return false;

            OpenManualActionMenu(target, mouse);
            return true;
        }

        private void HandleCanvasInput(Vector2 mouse)
        {
            Vector2 canvasTopLeft, canvasSize;
            CanvasRect.Get(out canvasTopLeft, out canvasSize);

            bool insideCanvas = PortGeometry.Contains(canvasTopLeft, canvasSize, mouse);

            // ---- marquee band (ADR-0048) ----
            // While the band is armed it owns the pointer completely. The wheel would change the
            // zoom under a rectangle that is being drawn in graph units, the right button would
            // pan the schema out from under it, and the hover highlights would light up the cards
            // the band is merely passing over — all of them repaint or move the picture in the
            // middle of the gesture.
            if (_marquee.IsArmed)
            {
                HandleMarqueeInput(mouse);
                return;
            }

            // ---- zoom ----
            if (insideCanvas)
            {
                int wheel = MyAPIGateway.Input.DeltaMouseScrollWheelValue();
                if (wheel != 0)
                {
                    // Zoom about the cursor so the point under the pointer stays put.
                    Vector2 graphUnderCursor = ScreenToGraph(mouse, canvasTopLeft);
                    float factor = wheel > 0 ? VgsConstants.ZoomStep : 1f / VgsConstants.ZoomStep;
                    float newZoom = _view.Zoom * factor;
                    if (newZoom < VgsConstants.MinZoom) newZoom = VgsConstants.MinZoom;
                    if (newZoom > VgsConstants.MaxZoom) newZoom = VgsConstants.MaxZoom;

                    if (newZoom != _view.Zoom)
                    {
                        _view.Zoom = newZoom;
                        _view.Camera = graphUnderCursor - (mouse - canvasTopLeft) / _view.Zoom;
                    }
                }
            }

            bool leftDown = MyAPIGateway.Input.IsLeftMousePressed();
            bool leftNew = MyAPIGateway.Input.IsNewLeftMousePressed();
            bool leftReleased = MyAPIGateway.Input.IsNewLeftMouseReleased();
            bool rightDown = MyAPIGateway.Input.IsRightMousePressed();
            bool middleDown = MyAPIGateway.Input.IsMiddleMousePressed();

            // ---- right click on a card: the manual action menu (ADR-0041) ----
            // Resolved before the pan, because the click and the pan share the right button: the
            // press only arms a candidate and the release decides between the two.
            if (HandleManualActionClick(mouse, canvasTopLeft, insideCanvas)) return;

            // ---- pan (right or middle button) ----
            // The right button pans unless the press landed on a card: while that candidate is
            // armed the press belongs to the click, and a pointer that travels drops the candidate
            // (in HandleManualActionClick) so the pan starts on the next frame instead of never.
            if (PanWhileHeld((rightDown && _rightClickNode == null) || middleDown, mouse,
                             canvasTopLeft, canvasSize)) return;

            // ---- hover: the remove button, the card's button row and the card ----
            UpdateHover(mouse, canvasTopLeft, canvasSize);

            if (leftNew && insideCanvas)
            {
                Vector2 graphPos = ScreenToGraph(mouse, canvasTopLeft);

                // The remove button is the smallest target on the canvas and it sits on a bar
                // that otherwise belongs to the card, so it is resolved before anything else:
                // a click meant to delete a connection must not select or drag the block.
                Port removePort;
                InputBar removeBar;
                Node removeNode = HitTestRemoveButton(graphPos, out removePort, out removeBar);
                if (removeNode != null)
                {
                    if (removeBar != null) RemoveBarConnections(removeNode, removeBar);
                    else RemovePortConnections(removeNode, removePort);
                    return;
                }

                // The pen on a parameterised input bar opens the argument dialog for *that
                // request* — the same target kind as the "x" beside it, resolved right after it
                // (ADR-0050).
                InputBar editBar;
                Node editNode = HitTestEditButton(graphPos, out editBar);
                if (editNode != null)
                {
                    BeginEditParameters(editNode, editBar);
                    return;
                }

                // A watch port's "x" is the same kind of target on the same kind of bar, and it
                // is resolved before the card for the same reason (ADR-0017).
                WatchTarget watchRemove;
                Node watchRemoveNode = HitTestWatchRemoveButton(graphPos, out watchRemove);
                if (watchRemoveNode != null)
                {
                    RemoveWatchTarget(watchRemoveNode, watchRemove);
                    return;
                }

                // The card's button row is resolved before the card itself: every button sits on
                // the card, and starting a gesture instead of a drag is the whole point of it
                // (ADR-0020). Which button it was decides what happens — the jump leaves the
                // schema for the block's own terminal (ADR-0021), a bell starts a watch, a
                // lightbulb or a plus starts a bind.
                CardButtonKind button;
                Node buttonNode = HitTestCardButton(graphPos, out button);
                if (buttonNode != null)
                {
                    PortGroup group;
                    switch (button)
                    {
                        case CardButtonKind.Jump:
                            TryJumpToTerminal(buttonNode);
                            break;

                        case CardButtonKind.Watch:
                            BeginWatch(buttonNode);
                            break;

                        default:
                            // Everything else is a bind, and the switch above names the two kinds
                            // that are not: a new kind of button added to the enum lands here as
                            // a bind, which is the safe default — it starts a gesture the player
                            // can cancel rather than doing something irreversible.
                            if (PortGeometry.TryGroupOf(button, out group))
                            {
                                BeginBind(buttonNode, group);
                            }
                            break;
                    }
                    return;
                }

                // The power switch sits in the card's state column and is a control, so it is
                // resolved before the card for the same reason the row is: a click there must
                // switch the block, not start dragging it across the canvas (ADR-0035).
                Node switchNode = HitTestPowerSwitch(graphPos);
                if (switchNode != null)
                {
                    ToggleBlockPower(switchNode);
                    return;
                }

                // ---- selection and the start of a drag (ADR-0048) ----
                //
                // Resolved after the controls above, because a click on a control is a click on a
                // control: it must neither select nor start a marquee, and every one of those
                // handlers returns before this point.
                Node hit = HitTest(graphPos);
                HandleSelectionPress(hit, graphPos);
                return;
            }

            if (leftDown && _draggedNode != null)
            {
                Vector2 graphPos = ScreenToGraph(mouse, canvasTopLeft);
                Vector2 target = graphPos - _dragGrabOffset;

                if (!_dragging)
                {
                    if ((target - _draggedNode.Position).Length() > VgsConstants.DragThreshold) _dragging = true;
                }

                if (_dragging)
                {
                    _draggedNode.Position = target;

                    // The frames of the groups this card belongs to follow it. Recomputed here,
                    // on the pointer move that changed the position, and not in the draw path:
                    // the same reason the graph itself is never read while drawing. Only the
                    // groups containing this card can have changed, so a drag costs a scan of
                    // the group list and one frame per group the card is in.
                    if (_graph.GroupCount > 0) PortGeometry.LayoutFramesContaining(_graph, _draggedNode);
                }
            }

            if (leftDown && _draggedGroup != null)
            {
                Vector2 graphPos = ScreenToGraph(mouse, canvasTopLeft);

                // The threshold is measured from where the strip was grabbed, not from the
                // previous frame: a slow drag would otherwise never accumulate enough movement
                // to start.
                if (!_dragging && (graphPos - _groupDragAnchor).Length() > VgsConstants.DragThreshold)
                {
                    _dragging = true;
                }

                if (_dragging)
                {
                    Vector2 delta = graphPos - _groupDragLast;
                    _groupDragLast = graphPos;

                    // One offset for the whole cluster: the members keep their positions
                    // relative to each other, which is the entire point of dragging a group
                    // rather than its cards one by one.
                    if (_graph.OffsetGroupMembers(_draggedGroup, delta) > 0)
                    {
                        // Every frame is derived from member cards, so all of them are
                        // recomputed: a card may belong to more than one group, and the frames
                        // of the others have to follow it too. Bounded by the group count and
                        // only while the pointer is actually moving.
                        PortGeometry.LayoutGroupFrames(_graph);
                    }
                }
            }

            if (leftDown && _dragCards.Count > 0)
            {
                Vector2 graphPos = ScreenToGraph(mouse, canvasTopLeft);

                // Measured from where the set was grabbed, like a group drag and for the same
                // reason: a slow drag would otherwise never accumulate enough movement to start.
                if (!_dragging && (graphPos - _selectionDragAnchor).Length() > VgsConstants.DragThreshold)
                {
                    _dragging = true;
                }

                if (_dragging)
                {
                    Vector2 delta = graphPos - _selectionDragLast;
                    _selectionDragLast = graphPos;

                    if (delta.X != 0f || delta.Y != 0f)
                    {
                        // One offset for the whole set, which is the group's rule (ADR-0016)
                        // applied to what the player selected: the cards keep their positions
                        // relative to each other, so a cluster does not come apart.
                        for (int i = 0; i < _dragCards.Count; i++)
                        {
                            Node card = _dragCards[i];
                            card.Position = card.Position + delta;
                        }

                        // Every frame is derived from the member cards, and a selected card may
                        // belong to more than one group, so all of them are recomputed — the same
                        // bounded pass a group drag pays, and only while the pointer moves.
                        if (_graph.GroupCount > 0) PortGeometry.LayoutGroupFrames(_graph);
                    }
                }
            }

            if (leftReleased)
            {
                // A press and a release without movement is a click even when the press kept the
                // set: a click on a card selects exactly that card. The set is kept on the press
                // only so that a drag of the whole selection can start (ADR-0048).
                if (!_dragging && _pendingSelectNode != null)
                {
                    _selection.Select(_pendingSelectNode);
                    VgsLog.Debug("selection collapsed to " + _pendingSelectNode + " by a click");
                }

                // Where the user dropped the card is written to the block here, on release.
                // Not per pointer move (sixty writes a second), and not in OnClosed: closing
                // can be a session unload, which never reaches OnClosed at all, and that is
                // exactly when a player would notice the layout was lost (ADR-0012).
                if (_dragging && _draggedNode != null) NodeStateStore.SavePosition(_draggedNode);
                if (_dragging && _draggedGroup != null) SaveGroupPositions(_draggedGroup);
                if (_dragging && _dragCards.Count > 0) SaveCardPositions(_dragCards);

                _draggedNode = null;
                _draggedGroup = null;
                _dragCards.Clear();
                _pendingSelectNode = null;
                _dragging = false;
            }
        }

        // ------------------------------------------------------------------ selection (ADR-0048)

        /// <summary>
        /// Turns a left press on the canvas into a selection edit and, when it is a grab, into the
        /// start of one of the three drags.
        ///
        /// <b>Shift always modifies the set; a plain press replaces it.</b> That is the whole rule,
        /// and it covers both gestures the player has: a Shift+click toggles the one node under the
        /// pointer, a Shift+press on the void arms a band that <em>adds</em> what it covers, while
        /// a plain press selects exactly the node it landed on and a plain press on the void clears
        /// the set and arms a band that replaces it.
        ///
        /// <b>A Shift+press starts no drag.</b> The gesture is an edit of the selection, and a
        /// press that also armed a drag would move the very card it was deselecting as soon as the
        /// hand twitched.
        ///
        /// <b>A press on a card that is already selected keeps the selection.</b> That is what
        /// makes "select several, then drag one of them" work: the press is the grab of the set,
        /// and replacing the set here would leave the drag with a single card — the set would
        /// visibly fall apart under the pointer on the first frame.
        ///
        /// <b>Which drag starts.</b> More than one selected node means the set is dragged by one
        /// offset (the group's rule, ADR-0016); otherwise it is the card's own drag or, for a
        /// group, its title-strip drag. A group's port bars remain no handle at all (ADR-0016),
        /// including in a multi-node selection.
        /// </summary>
        private void HandleSelectionPress(Node hit, Vector2 graphPos)
        {
            bool shift = MyAPIGateway.Input.IsAnyShiftKeyPressed();

            if (shift)
            {
                if (hit != null)
                {
                    bool selected = _selection.Toggle(hit);
                    VgsLog.Debug("selection: " + hit + (selected ? " added" : " removed") + ", "
                                 + _selection.Count + " node(s) selected");
                    return;
                }

                // Shift on the void: a band that adds to the set instead of replacing it.
                _marquee.Begin(graphPos, true);
                return;
            }

            // Only one drag can be in progress: the three kinds write to different things (one
            // position, one offset on a group's members, one offset on the selected cards), and
            // two running at once would move the same card twice per frame. Clearing them here is
            // cheaper than defending every use site against a stale one.
            _draggedNode = null;
            _draggedGroup = null;
            _dragCards.Clear();
            _pendingSelectNode = null;
            _dragging = false;

            if (hit == null)
            {
                // A press on the void: the set is replaced by whatever the band will cover, which
                // is nothing at all when the hand does not move.
                _selection.Clear();
                _marquee.Begin(graphPos, false);
                return;
            }

            if (!_selection.Contains(hit)) _selection.Select(hit);
            else if (_selection.Count > 1) _pendingSelectNode = hit;

            // A group is dragged by its title strip only (ADR-0016). The interior of the frame
            // belongs to the member cards and the gaps between them stay canvas, so a click there
            // still starts a band — a frame that swallowed those clicks would make the cluster
            // impossible to pan across. The group is selected all the same: the click landed on
            // its frame, and a set of one group is what the player then sees outlined.
            if (hit.IsGroup && !PortGeometry.HitGroupTitle(hit, graphPos)) return;

            // A press on a card that is already part of a set keeps the set: the drag that may
            // follow needs all of it. The collapse back to this one card happens on release, and
            // only if no drag happened — see the release branch of HandleCanvasInput.
            if (_selection.Count > 1)
            {
                // A selected group contributes its drawn members, and a card may be in two of
                // them; the list is deduplicated by CollectDragCards, so every card moves once.
                _selection.CollectDragCards(_graph, _dragCards);
                _selectionDragAnchor = graphPos;
                _selectionDragLast = graphPos;
                return;
            }

            if (hit.IsGroup)
            {
                _draggedGroup = hit;
                _groupDragAnchor = graphPos;
                _groupDragLast = graphPos;
                return;
            }

            _draggedNode = hit;
            _dragGrabOffset = graphPos - hit.Position;
        }

        /// <summary>
        /// Input while the marquee band is armed: track the pointer, and on release select the
        /// cards the band covers (ADR-0048).
        ///
        /// <b>The release is read as "the button is up", not as "the release event happened".</b>
        /// A long frame can swallow the event, and a band that stayed on screen because of a missed
        /// event would keep the canvas frozen until the next click. The press frame itself never
        /// reaches this method — it arms the band and returns from
        /// <see cref="HandleSelectionPress"/> — so a button that is already up here means the
        /// gesture is over.
        ///
        /// <b>A right click drops the band</b> without selecting anything, which is the same
        /// "right click cancels the gesture" rule the bind and the watch follow. The left button
        /// is still held, so nothing else starts until it is released.
        /// </summary>
        private void HandleMarqueeInput(Vector2 mouse)
        {
            if (MyAPIGateway.Input.IsNewRightMousePressed())
            {
                _marquee.Cancel();
                return;
            }

            // Nothing under the pointer is "hovered" while a band is being drawn: the band is
            // what the player is aiming at, and a card lighting up as the band crosses it would
            // read as "this one is picked" while the band is still moving.
            ClearHoverTargets();

            Vector2 canvasTopLeft, canvasSize;
            CanvasRect.Get(out canvasTopLeft, out canvasSize);

            if (MyAPIGateway.Input.IsLeftMousePressed())
            {
                _marquee.Move(ScreenToGraph(mouse, canvasTopLeft), _view.Zoom,
                              VgsScreenDraw.ClientWidth, VgsScreenDraw.ClientHeight);
                return;
            }

            FinishMarquee();
        }

        /// <summary>
        /// Ends the marquee: selects what the band covers, or does nothing when the press never
        /// became a band.
        ///
        /// The two cases are not the same gesture and must not be merged: a band that covered
        /// nothing selects nothing (the player dragged over the void), while a press that never
        /// moved is a click on the void — and a plain click there has already cleared the set when
        /// the press was handled. A Shift+click on the void therefore leaves the set alone, which
        /// is what "Shift modifies, it does not replace" means.
        /// </summary>
        private void FinishMarquee()
        {
            bool additive = _marquee.Additive;
            bool active = _marquee.IsActive;

            Vector2 topLeft, size;
            _marquee.Normalize(out topLeft, out size);
            _marquee.Cancel();

            if (!active) return;

            _selection.SelectInRect(_graph, topLeft, size, additive);

            VgsLog.Debug("marquee " + (additive ? "added to" : "replaced") + " the selection: "
                         + _selection.Count + " node(s) selected");
        }

        /// <summary>
        /// Writes the new position of every card a selection drag moved (ADR-0012, ADR-0048).
        ///
        /// The same contract as <see cref="SaveGroupPositions"/>: the layout lives on the blocks,
        /// a card has nowhere else to store it, and a block destroyed mid-drag is skipped rather
        /// than reported as an error.
        /// </summary>
        private void SaveCardPositions(List<Node> cards)
        {
            if (cards == null) return;

            int saved = 0;
            for (int i = 0; i < cards.Count; i++)
            {
                if (NodeStateStore.SavePosition(cards[i])) saved++;
            }

            VgsLog.Info("selection moved: " + saved + " card position(s) saved");
        }

        /// <summary>
        /// Writes the new position of every member card of a dragged group to its block
        /// (ADR-0012, ADR-0016).
        ///
        /// A group has nowhere to store a position: it is not an entity and has no mod storage.
        /// The group's layout *is* its members' layouts, so saving the group means saving each
        /// member — and that is also what makes a dragged group survive a reload exactly like a
        /// dragged card.
        ///
        /// Members whose block disappeared mid-drag are skipped: <see cref="NodeStateStore.SavePosition"/>
        /// reports that as false, which is a normal outcome, not an error.
        /// </summary>
        private void SaveGroupPositions(Node group)
        {
            if (group == null) return;

            int saved = 0;
            for (int i = 0; i < group.Members.Count; i++)
            {
                Node member = _graph.GetNode(group.Members[i]);
                if (member == null || member.IsGroup) continue;
                if (NodeStateStore.SavePosition(member)) saved++;
            }

            VgsLog.Info("group '" + group.GroupName + "' moved: " + saved + " card position(s) saved");
        }

        /// <summary>
        /// Input while a bind is in progress: the pointer picks the target instead of dragging
        /// or panning. The right button cancels — which is why the right button cannot pan
        /// here; the middle button still does.
        /// </summary>
        private void HandleBindInput(Vector2 mouse)
        {
            bool rightNew = MyAPIGateway.Input.IsNewRightMousePressed();
            if (rightNew)
            {
                CancelBind();
                return;
            }

            Vector2 canvasTopLeft, canvasSize;
            CanvasRect.Get(out canvasTopLeft, out canvasSize);
            bool insideCanvas = PortGeometry.Contains(canvasTopLeft, canvasSize, mouse);

            // Middle-button pan keeps working so the user can reach a target off-screen
            // without losing the bind.
            if (PanWithMiddleButton(mouse, canvasTopLeft, canvasSize)) return;

            Vector2 graphPos = ScreenToGraph(mouse, canvasTopLeft);

            // A pointer over the header or the bottom bar is not over a card, even if a card
            // happens to be scrolled underneath: the bars are chrome, and the click there is
            // a click on chrome.
            //
            // The port controls are idle-mode targets only: while binding, every click picks the
            // target, and a bar (with its button) counts as its block. Dropping those highlights
            // is what stops a disc from looking clickable in a mode where it is not.
            ClearHoverTargets();
            _hoverNode = insideCanvas ? HitTest(graphPos) : null;

            if (!MyAPIGateway.Input.IsNewLeftMousePressed()) return;

            Node target = _hoverNode;
            if (target == null)
            {
                // Clicking the void abandons the bind, the same way a rubber band in any
                // editor is dropped by clicking on nothing.
                CancelBind();
                return;
            }

            // The target is decided, so from this moment the pending line belongs to that card
            // rather than to the pointer: the player has already answered "which block", and only
            // "which action, with which values" is still open (ADR-0052 §5).
            _bindTarget = target;

            // A click on the source itself is a legal target: a block may drive itself, and the
            // game fires such an item exactly like any other (ADR-0036). No special case is
            // needed here — the action menu below is the source's own action list, and the
            // write path does not care that source and target are one block.
            OpenActionMenu(target, mouse, ActionMenuMode.Bind);
        }

        // ------------------------------------------------------------------ watch mode

        /// <summary>
        /// Input while a watch is being attached to a controller (ADR-0017).
        ///
        /// The gesture is the bind's twin and deliberately so: a line follows the pointer from
        /// the controller's bell, the left button picks the block, the right button and Esc
        /// cancel, the middle button still pans so a target off-screen can be reached without
        /// losing the gesture. What differs is what a click *means*: no action menu opens,
        /// because there is no action to choose — the controller only observes.
        /// </summary>
        private void HandleWatchInput(Vector2 mouse)
        {
            if (MyAPIGateway.Input.IsNewRightMousePressed())
            {
                CancelWatch();
                return;
            }

            Vector2 canvasTopLeft, canvasSize;
            CanvasRect.Get(out canvasTopLeft, out canvasSize);
            bool insideCanvas = PortGeometry.Contains(canvasTopLeft, canvasSize, mouse);

            if (PanWithMiddleButton(mouse, canvasTopLeft, canvasSize)) return;

            Vector2 graphPos = ScreenToGraph(mouse, canvasTopLeft);

            // The port controls are idle-mode targets only: while a watch is being attached,
            // every click picks a block, and a bar counts as its block.
            ClearHoverTargets();
            _hoverNode = insideCanvas ? HitTest(graphPos) : null;

            if (!MyAPIGateway.Input.IsNewLeftMousePressed()) return;

            Node target = _hoverNode;
            if (target == null)
            {
                // Clicking the void abandons the gesture, exactly like a bind.
                CancelWatch();
                return;
            }

            TryAttachWatch(target);
        }

        /// <summary>
        /// Starts watch mode from a controller's watch button. Refuses on a node that is not a
        /// controller, and on one whose list cannot be written from this machine — telling the
        /// player before they aim at a block rather than after.
        /// </summary>
        private void BeginWatch(Node controller)
        {
            if (controller == null || !controller.IsEventController) return;

            _watchSource = controller;
            _watchErrorUntilFrame = 0;

            // The selection is deliberately left alone. A gesture is a gesture on one card — the
            // one under the pointer, marked by the hover outline and by the line that leaves it —
            // while the selection is the player's working set, and a control press that quietly
            // replaced a set of ten with one would be a side effect nobody asked for (ADR-0048).
            _dragging = false;
            _draggedNode = null;
            _draggedGroup = null;
            _dragCards.Clear();
            CancelBind();

            VgsLog.Debug("watch mode started on controller " + controller.EntityId);
        }

        /// <summary>
        /// Leaves watch mode. Deliberately does not touch the selection or the camera: the
        /// player is looking at the controller they just edited.
        /// </summary>
        private void CancelWatch()
        {
            if (_watchSource != null) VgsLog.Debug("watch mode cancelled");

            _watchSource = null;
            ResetPointerOverlay();
        }

        /// <summary>
        /// Attaches one block to the controller being edited, or refuses and turns the line red.
        ///
        /// <b>Order: reserve in the graph, write the block, keep the picture only on success.</b>
        /// The block is the record — the game's selection plus the overlay, never the graph
        /// (ADR-0018) — and the port is only its picture. The reservation is what makes a refusal
        /// cost nothing: it answers the cheap questions first (is this a controller, is the block
        /// already watched, is the stack full) and rolls back without a trace when the world
        /// refuses. `LayoutPorts` is not called between the two, so no port is ever drawn for a
        /// watch that did not happen.
        /// </summary>
        private void TryAttachWatch(Node target)
        {
            Node controller = _watchSource;
            if (controller == null || target == null) return;

            // A group is not an entity, so it has no id to store and nothing the controller
            // could subscribe to (ADR-0015, ADR-0017). Refused explicitly: falling through to
            // "the block is gone" would be a lie about a block the player can see.
            if (target.IsGroup)
            {
                RefuseWatch(VgsText.WarnWatchGroup);
                return;
            }

            IMyTerminalBlock controllerBlock = ResolveBlock(controller.EntityId);
            if (controllerBlock == null)
            {
                RefuseWatch(VgsText.WarnWatchBlockGone);
                return;
            }

            IMyTerminalBlock targetBlock = ResolveBlock(target.EntityId);
            if (targetBlock == null)
            {
                RefuseWatch(VgsText.WarnWatchBlockGone);
                return;
            }

            // A controller may watch itself (ADR-0036): the engine's ValidateBlock asks only for
            // the same construct, and the event component subscribes the controller like any
            // other block. The bar then carries the controller's own name.
            if (_graph.HasWatch(controller, target.EntityId))
            {
                RefuseWatch(string.Format(VgsText.WarnWatchDuplicateFormat, target.DisplayName));
                return;
            }

            // The stack is capped, and the cap is enforced before the write so the refusal costs
            // nothing. A bar with no drawing slot would have no "x", and that button is the only
            // way to detach a block.
            if (controller.Controller != null && controller.Controller.IsFull)
            {
                RefuseWatch(string.Format(VgsText.WarnWatchTooManyFormat, GridGraph.MaxPortsPerSide));
                return;
            }

            // The graph is the reservation: it answers the cheap questions (is this a
            // controller, is the block already watched) before a single read of the world.
            if (!_graph.TryAddWatch(controller, target.EntityId, target.DisplayName))
            {
                RefuseWatch(VgsText.WarnWatchRejected);
                return;
            }

            EventControllerProbe.WatchResult result =
                EventControllerProbe.TryAddWatch(controllerBlock, targetBlock);

            if (result != EventControllerProbe.WatchResult.Ok)
            {
                _graph.RemoveWatch(controller, target.EntityId);
                RefuseWatch(DescribeWatchFailure(result, controllerBlock, target));
                return;
            }

            _graph.LayoutPorts();
            if (_graph.GroupCount > 0) PortGeometry.LayoutGroupFrames(_graph);

            VgsLog.Info("controller " + controller.EntityId + " now watches " + target.EntityId);
        }

        /// <summary>
        /// Removes a block from a controller's watch list from the port's "x".
        ///
        /// <b>Order: block first, graph second</b> — the mirror of attaching, and for the same
        /// reason: the block is the record, the port is its picture (ADR-0018). A refused removal
        /// keeps the port and says why, because dropping the bar while the block stayed watched
        /// would hide a live watch — and a block the player selected in the vanilla terminal
        /// cannot be removed from here at all, so it answers with that instead.
        /// </summary>
        private void RemoveWatchTarget(Node controller, WatchTarget watch)
        {
            if (controller == null || watch == null) return;

            IMyTerminalBlock controllerBlock = ResolveBlock(controller.EntityId);
            if (controllerBlock == null)
            {
                Warn(VgsText.WarnWatchBlockGone);
                return;
            }

            IMyTerminalBlock targetBlock = ResolveBlock(watch.EntityId);

            // A block that no longer exists has nothing left to unsubscribe from: the entry is
            // dropped from the storage and the bar goes with it. Refusing here would leave the
            // player with a port they can never remove.
            EventControllerProbe.WatchResult result;
            if (targetBlock == null)
            {
                result = EventControllerProbe.ForgetWatch(controllerBlock, watch.EntityId)
                    ? EventControllerProbe.WatchResult.Ok
                    : EventControllerProbe.WatchResult.Rejected;
            }
            else
            {
                result = EventControllerProbe.TryRemoveWatch(controllerBlock, targetBlock);
            }

            if (result != EventControllerProbe.WatchResult.Ok)
            {
                // A client is not a refusal of the game's — it is a different machine. Saying
                // "the game did not accept it" there would be untrue and would send the player
                // looking for a problem that does not exist.
                if (result == EventControllerProbe.WatchResult.ClientNotServer)
                {
                    Warn(VgsText.WarnWatchClient);
                    return;
                }

                // A block the player selected in the vanilla terminal is not ours to remove: the
                // controller's own list has no public setter, so the port would return on the
                // next refresh anyway (ADR-0018). Sending them to the terminal is the truth.
                if (result == EventControllerProbe.WatchResult.GameOwned)
                {
                    Warn(string.Format(VgsText.WarnWatchGameOwnedFormat, watch.DisplayName));
                    return;
                }

                Warn(string.Format(VgsText.WarnWatchRemoveRejectedFormat, watch.DisplayName));
                return;
            }

            _graph.RemoveWatch(controller, watch.EntityId);
            _hoverWatchRemoveNode = null;
            _hoverWatchRemoveTarget = null;

            _graph.LayoutPorts();
            if (_graph.GroupCount > 0) PortGeometry.LayoutGroupFrames(_graph);

            VgsLog.Info("controller " + controller.EntityId + " no longer watches " + watch.EntityId);
        }

        /// <summary>
        /// Reports a refused attach: the line turns red for
        /// <see cref="VgsConstants.WatchErrorFrames"/>, the reason goes to the bottom bar, and
        /// watch mode stays on so the next click can land on a block that fits.
        /// </summary>
        private void RefuseWatch(string reason)
        {
            _watchErrorUntilFrame = _screenFrame + VgsConstants.WatchErrorFrames;
            Warn(reason);
        }

        /// <summary>
        /// Turns a refusal into the sentence the player sees. Each reason has its own wording
        /// because they call for different actions: a different block, a different event, or a
        /// different machine.
        /// </summary>
        private string DescribeWatchFailure(EventControllerProbe.WatchResult result,
                                            IMyTerminalBlock controllerBlock, Node target)
        {
            switch (result)
            {
                case EventControllerProbe.WatchResult.Duplicate:
                    return string.Format(VgsText.WarnWatchDuplicateFormat, target.DisplayName);
                case EventControllerProbe.WatchResult.NoEvent:
                    return VgsText.WarnWatchNoEvent;
                case EventControllerProbe.WatchResult.EventIgnoresBlocks:
                    return VgsText.WarnWatchEventIgnoresBlocks;
                case EventControllerProbe.WatchResult.DifferentConstruct:
                    return VgsText.WarnWatchDifferentConstruct;
                case EventControllerProbe.WatchResult.NotAccepted:
                    return string.Format(VgsText.WarnWatchNotAcceptedFormat, target.DisplayName,
                                         EventControllerProbe.SelectedEventName(controllerBlock));
                case EventControllerProbe.WatchResult.ClientNotServer:
                    return VgsText.WarnWatchClient;
                case EventControllerProbe.WatchResult.BlockGone:
                    return VgsText.WarnWatchBlockGone;
                default:
                    return VgsText.WarnWatchRejected;
            }
        }

        /// <summary>
        /// Input while an action menu is open — the bind's menu or the manual one (ADR-0041).
        ///
        /// Everything is shared but the meaning of a row: identical geometry, identical scroll,
        /// identical "a click outside is a miss" rule. A right click and Esc leave the menu in
        /// both modes; in bind mode that is also leaving the gesture, because the menu is the last
        /// step of it.
        /// </summary>
        private void HandleMenuInput(Vector2 mouse)
        {
            if (MyAPIGateway.Input.IsNewRightMousePressed())
            {
                DismissActionMenu();
                return;
            }

            int hoverRow = MenuRowAt(mouse);
            _menuHoverRow = hoverRow;

            int wheel = MyAPIGateway.Input.DeltaMouseScrollWheelValue();
            if (wheel != 0) ScrollMenu(wheel > 0 ? -1 : 1);

            if (!MyAPIGateway.Input.IsNewLeftMousePressed()) return;

            Vector2 menuTopLeft, menuSize;
            GetMenuRect(out menuTopLeft, out menuSize);
            bool insideMenu = PortGeometry.Contains(menuTopLeft, menuSize, mouse);

            if (!insideMenu)
            {
                // A click next to the menu is a miss, not a decision: close the menu but keep the
                // bind (if there is one), so a near-miss does not cost the user the source they
                // picked. The manual menu has no gesture to keep, so the click simply ends it.
                CloseActionMenu();
                return;
            }

            if (_menuRows.Count == 0)
            {
                // The target offers no actions at all, so nothing can be chosen. Say so — the row
                // that is drawn says it — and drop the whole gesture rather than leaving an
                // unclickable menu on screen.
                VgsLog.Debug(_menuMode == ActionMenuMode.Manual
                                 ? "manual action menu closed: target has no terminal actions"
                                 : "bind cancelled: target has no terminal actions");
                DismissActionMenu();
                return;
            }

            if (hoverRow < 0) return;   // title strip

            Port action = _menuRows[hoverRow];

            if (_menuMode == ActionMenuMode.Manual)
            {
                TryRunManualAction(action);
                return;
            }

            if (TryCompleteBind(action))
            {
                CloseActionMenu();
                CancelBind();
                return;
            }

            // The dialog owns the request from here: the menu closes, the bind stays armed so that
            // Cancel returns the player to the schema with the source still chosen, and the pending
            // line stays anchored to the target card — it must not start following the pointer
            // again, because the target is decided (ADR-0052 §5).
            if (ParameterDialogOpen) return;

            // Nothing was created and nothing is being asked for: the temporary line goes with the
            // gesture, exactly as it did before there was a dialog.
            CancelBind();
        }

        /// <summary>
        /// Runs the chosen row on its target and leaves the menu — the manual mode's answer to a
        /// clicked row (ADR-0041).
        ///
        /// <b>Order: run, then close, and close only on success.</b> The action was asked for once,
        /// so a second click is a second action rather than a repeat of the first; and a refusal
        /// keeps the menu open with the reason on the bottom bar, exactly like a refused bind, so
        /// the player can pick another row instead of reopening the menu to retry.
        ///
        /// Nothing is written to the graph or to a toolbar: the group of an action is its target,
        /// not a connection (ADR-0011). What changes is the block, and the card catches up through
        /// the ordinary state pass or the next structural refresh — no cache is patched here.
        /// </summary>
        private void TryRunManualAction(Port action)
        {
            Node target = _menuTarget;
            if (target == null || action == null) return;

            int applied;

            // The grid is only needed to find a group's members through the terminal system; a
            // block is its own entity and needs no such indirection.
            long groupGridId = target.IsGroup ? GroupGridEntityId(target) : 0L;

            TerminalActionRunner.RunResult result =
                TerminalActionRunner.TryRun(target, action, groupGridId, out applied);

            if (result == TerminalActionRunner.RunResult.Ok)
            {
                VgsLog.Info("manual action " + action.Key + " on "
                            + (target.IsGroup ? "group:" + target.GroupName : target.EntityId.ToString())
                            + " applied to " + applied + " block(s)");
                CloseActionMenu();
                return;
            }

            Warn(DescribeManualFailure(result, target, action));
        }

        /// <summary>
        /// The grid whose terminal system knows the group the frame stands for.
        ///
        /// A group is not an entity, so the lookup starts from a block on the same construct
        /// (`docs/01-research/api-block-groups.md` §1: the system is the *logical* grid group's,
        /// covering subgrids). Any drawn member's grid answers it; the editor's own grid is the
        /// fallback for a group whose members are all on grids the graph could not name. Read from
        /// cached node values, so it costs nothing and cannot throw.
        /// </summary>
        private long GroupGridEntityId(Node group)
        {
            for (int i = 0; i < group.Members.Count; i++)
            {
                Node member = _graph.GetNode(group.Members[i]);
                if (member != null && member.GridEntityId != 0) return member.GridEntityId;
            }
            return _graph.GridEntityId;
        }

        /// <summary>
        /// Turns a refusal into the sentence the player sees. Each reason has its own wording
        /// because they call for different actions: a rebuilt block needs a refresh, a vanished
        /// group needs the group fixed in the terminal, a throw means the game itself declined.
        /// </summary>
        private static string DescribeManualFailure(TerminalActionRunner.RunResult result, Node target,
                                                    Port action)
        {
            switch (result)
            {
                case TerminalActionRunner.RunResult.BlockGone:
                    return VgsText.WarnManualBlockGone;
                case TerminalActionRunner.RunResult.ActionGone:
                    // The same sentence for a block and for a group: "«target» has no action
                    // «action»" is true of both, and which one it was is already visible on the
                    // frame the menu was opened for.
                    return string.Format(VgsText.WarnManualActionGoneFormat, target.DisplayName,
                                         action.DisplayName);
                case TerminalActionRunner.RunResult.GroupGone:
                    return string.Format(VgsText.WarnManualGroupGoneFormat, target.GroupName);
                default:
                    return VgsText.WarnManualRejected;
            }
        }

        // ------------------------------------------------------------------ jump to the block

        /// <summary>
        /// Leaves the schema for the block's own terminal (ADR-0021): switches the game's terminal
        /// to this block and closes the editor.
        ///
        /// <b>Close only on success.</b> This is the one card action that destroys the screen the
        /// player is looking at, so a refusal — the block was destroyed since the last refresh, or
        /// there is no local character to open a terminal for — has to leave the schema where it
        /// was and say why in the bottom bar. Closing first and reporting afterwards would cost
        /// the player their place over a block that no longer exists.
        ///
        /// <b>Switch the terminal before closing.</b> Closing is a transition that finishes over
        /// the next frames, while the terminal's tab rebuild is immediate; in this order the
        /// terminal already shows the right block by the time the closing screen uncovers it.
        ///
        /// A group is refused rather than attempted: it has no entity, so there is no terminal it
        /// could stand for. The button is not drawn on a group's frame either
        /// (<see cref="PortGeometry.HasCardButton"/>), so this is only a guard.
        /// </summary>
        private void TryJumpToTerminal(Node node)
        {
            if (node == null || node.IsGroup) return;

            string failure;
            if (!TerminalJump.TryOpen(node.EntityId, out failure))
            {
                // Warn both shows the sentence and writes it to the log — one line per event.
                Warn(failure ?? VgsText.WarnJumpFailed);
                return;
            }

            VgsLog.Info("terminal jump to block " + node.EntityId + ", closing the editor");

            // Closing is a separate call into the game, and the terminal has already been switched
            // by now. A throw here would reach the caller's throttled handler and read as "input
            // handling failed", which is not what happened — so it is caught here, where the state
            // is known: the jump succeeded, only the close did not, and the player can press Esc.
            try
            {
                Close();
            }
            catch (Exception e)
            {
                VgsLog.Error("terminal jump succeeded but the editor could not close", e);
            }
        }

        // ------------------------------------------------------------------ block power switch

        /// <summary>
        /// Switches a block on or off from the card's power switch (ADR-0035).
        ///
        /// <b>Order: refuse first, write the block, then update the picture from what the block
        /// says.</b> The refusal is the cheap part and it is the part the player needs to hear
        /// about: a block damaged below its critical integrity cannot be switched on, and the game
        /// would accept the flag and then not run the block, so the editor refuses it here with a
        /// sentence instead of leaving a green switch on a dead block.
        ///
        /// <b>The graph is not asked; the block is.</b> After the write, the node's state is
        /// rewritten from a fresh read of the block — not toggled in place — because the request
        /// can be refused (a remote client sends it to the server) and because the block may have
        /// changed between the last state pass and this click. Toggling a cached value would be a
        /// guess about the world, which is the one thing this project does not do (ADR-0018).
        ///
        /// The node itself is left alone: no ports, no slots, no frame. Switching a block off does
        /// not unwire it — the toolbar item stays, and the block simply does nothing until it is
        /// switched back on.
        /// </summary>
        private void ToggleBlockPower(Node node)
        {
            if (node == null || node.IsGroup) return;

            IMyTerminalBlock block = ResolveBlock(node.EntityId);
            if (block == null)
            {
                Warn(VgsText.WarnBlockGone);
                return;
            }

            BlockPower current = node.State.Power;

            // The state pass has not reached this card yet: there is nothing to flip, and guessing
            // "off" would switch on a block that is already on. Refusing quietly is right here —
            // the player did not do anything wrong, the reading is just half a second away.
            if (current == BlockPower.Unknown) return;

            if (current == BlockPower.Unavailable)
            {
                Warn(VgsText.WarnPowerDamaged);
                return;
            }

            bool wanted = current != BlockPower.On;

            // Switching on is the direction that can be refused by the block's own condition, so
            // the functional flag is re-read here rather than trusted from the last pass: the
            // block may have been hit since. Switching off is always allowed.
            if (wanted)
            {
                bool enabled, functional;
                if (BlockSwitch.TryRead(block, out enabled, out functional) && !functional)
                {
                    Warn(VgsText.WarnPowerDamaged);

                    // The card is corrected now rather than on the next tick: the player just
                    // learned the block is broken, and a grey switch for another half second
                    // would contradict the sentence on the bar.
                    node.State.SetPower(enabled, functional);
                    return;
                }
            }

            if (!BlockSwitch.TrySetEnabled(block, wanted))
            {
                Warn(VgsText.WarnPowerRefused);

                // The block did not take the value, so the picture is re-read instead of toggled:
                // whatever it reports now is the truth, including "no change".
                bool enabled, functional;
                if (BlockSwitch.TryRead(block, out enabled, out functional))
                {
                    node.State.SetPower(enabled, functional);
                }
                return;
            }

            // Read back: the flag the block reports after the request is what the card shows.
            bool nowEnabled, nowFunctional;
            if (BlockSwitch.TryRead(block, out nowEnabled, out nowFunctional))
            {
                node.State.SetPower(nowEnabled, nowFunctional);
            }

            VgsLog.Info("block " + node.EntityId + " switched " + (wanted ? "on" : "off"));
        }

        /// <summary>Topmost node whose power switch is under the pointer, or null.</summary>
        private Node HitTestPowerSwitch(Vector2 graphPoint)
        {
            float aspect = VgsScreenDraw.ClientAspect;

            IList<Node> nodes = _graph.Nodes;
            for (int i = nodes.Count - 1; i >= 0; i--)
            {
                if (PortGeometry.HitPowerSwitch(nodes[i], graphPoint, aspect)) return nodes[i];
            }
            return null;
        }

        // ------------------------------------------------------------------ bind mode

        private void BeginBind(Node source, PortGroup group)
        {
            if (source == null) return;

            Port port = source.PrimaryEventFor(group);
            if (port == null)
            {
                VgsLog.Debug("bind not started: block has no port for group " + group);
                return;
            }

            // <b>Clear first, then set.</b> `_bindTarget` belongs to the previous gesture and a
            // bind that started without it being cleared would draw its pending line to a card the
            // player never chose (ADR-0052 §5). Today no path reaches here with a target set, and
            // that is exactly the kind of invariant a field-by-field reset stops being true about
            // the day a fourth field appears.
            _bindTarget = null;

            _bindSource = source;
            _bindPort = port;
            _bindGroup = group;

            // The selection is left alone — see BeginWatch. The source card is marked by the
            // hover outline and by the pending line that leaves its port dot.
            _dragging = false;
            _draggedNode = null;
            _draggedGroup = null;
            _dragCards.Clear();
            _panning = false;
            CloseActionMenu();

            VgsLog.Debug("bind started from " + source.EntityId + " via " + port.Key);
        }

        private void CancelBind()
        {
            if (_bindSource != null) VgsLog.Debug("bind cancelled");
            _bindSource = null;
            _bindPort = null;
            _bindTarget = null;
            ResetPointerOverlay();
            CloseActionMenu();
        }

        /// <summary>
        /// Opens the action menu for a target: the same rows in both modes, a different meaning
        /// for a click.
        ///
        /// Bind mode opens it after the source's button and a click on the target (ADR-0010 §5);
        /// idle mode opens it with a right click on a card (ADR-0041). The rows, the captions, the
        /// scroll and the fan-in counts are shared — a player who saw the list while binding sees
        /// exactly the same list here, which is the whole point of the manual mode.
        /// </summary>
        private void OpenActionMenu(Node target, Vector2 mouse, ActionMenuMode mode)
        {
            if (target == null) return;

            _menuTarget = target;
            _menuMode = mode;
            _menuAnchorScreen = mouse;
            _menuScroll = 0;
            _menuHoverRow = -1;

            // The target card keeps the hover outline while its menu is open, so it is obvious
            // which of several similar blocks the list belongs to.
            ClearHoverTargets();
            _hoverNode = target;

            _menuRows.Clear();
            _menuLabels.Clear();

            FillMenuRows(target);

            // The log is the only place a wrong list can be diagnosed from: the editor shows the
            // block's own actions, so a report of "the event controller offers font actions" is
            // answered by this line naming the block and every id that was read.
            //
            // The type name comes before the subtype because the subtype is empty for the game's
            // "default" definitions (Door, OxygenTank, AirVent, ...) — the eight blocks ADR-0043
            // was written for — and a log line that starts with two spaces names nothing. The
            // subtype stays in the line: it is the identity a bug report is searched by, and the
            // type name is what the player saw on the card.
            //
            // A group has neither of those: no type, no subtype and no entity id (ADR-0015). It
            // is named the way the rest of this file names one — "group:<name>" — or the line
            // would read "for [] (0)", which is the very thing the type name was added to fix.
            VgsLog.Info((mode == ActionMenuMode.Manual ? "manual action menu for " : "action menu for ")
                        + (target.IsGroup
                               ? "group:" + target.GroupName
                               : target.TypeDisplayName + " [" + target.SubtypeId + "] ("
                                 + target.EntityId + ")")
                        + ": " + _menuRows.Count + " action(s): " + JoinActionIds(_menuRows));
        }

        /// <summary>
        /// Opens the manual action menu — the one a right click on a card produces (ADR-0041).
        ///
        /// A group frame is a legal target for the same reason it is a legal target while
        /// binding: it has an action list of its own (ADR-0015), and the rows are the game's own
        /// rule for the group, so running one applies it to the whole group exactly as a wired
        /// group item would.
        ///
        /// <b>It does not move the selection.</b> A right click is a look, not a choice of what
        /// the next gesture works on; the card under it keeps the hover outline while the menu is
        /// open (set by <see cref="OpenActionMenu"/>), which marks the target without editing what
        /// the player had selected.
        /// </summary>
        private void OpenManualActionMenu(Node target, Vector2 mouse)
        {
            if (target == null) return;
            OpenActionMenu(target, mouse, ActionMenuMode.Manual);
        }

        /// <summary>
        /// Closes the action menu and, when a bind is in progress, ends that too. The one way out
        /// for both menus: a bind's menu is part of the gesture, so closing it without ending the
        /// gesture would leave a line following the pointer that can no longer be completed; a
        /// manual menu has no gesture behind it and is simply closed (ADR-0041).
        /// </summary>
        private void DismissActionMenu()
        {
            // CancelBind closes the menu as part of leaving the gesture, because the menu is that
            // gesture's last step. The manual menu has no gesture behind it and is closed directly.
            if (_bindSource != null) CancelBind();
            else CloseActionMenu();
        }

        /// <summary>
        /// Fills the menu rows and their captions for one target.
        ///
        /// Called when the menu opens and again on every grid refresh while it stays open,
        /// because the captions carry the current fan-in count. Both call sites are outside the
        /// draw path on purpose: <see cref="DrawActionMenu"/> must only read these lists.
        /// </summary>
        private void FillMenuRows(Node target)
        {
            _menuRows.Clear();
            _menuLabels.Clear();
            _menuTitle = null;
            _menuCountLabel = null;
            if (target == null) return;

            // The manual menu is titled by the mode and the bind menu by the target: "Manual
            // action" is what the player asked for and what the card under the pointer already
            // identifies, while the bind menu has to name the block it is aiming an action at.
            // The fan-in counters are kept in both — they describe the target's input port, and
            // a manual menu that dropped them would no longer be the same list (ADR-0041).
            _menuTitle = _menuMode == ActionMenuMode.Manual
                ? VgsText.ManualActionTitle
                : string.Format(VgsText.ActionMenuTitleFormat, target.DisplayName);

            for (int i = 0; i < target.Actions.Count; i++)
            {
                Port action = target.Actions[i];
                _menuRows.Add(action);

                // Input ports are shared, so an action that already has sources is still a
                // valid choice — the row says how many lines are already there instead of
                // being disabled. A disabled row would also make the menu jump as soon as the
                // user connected something.
                int fanIn = _graph.CountEdgesToInput(target, action.Key);
                _menuLabels.Add(fanIn > 0
                    ? action.DisplayName + string.Format(VgsText.ActionMenuFanInFormat, fanIn)
                    : action.DisplayName);
            }

            // The row count can shrink under an open menu; the scroll offset must not point
            // past the end, or the last rows become unreachable.
            int maxScroll = _menuRows.Count - VgsConstants.ActionMenuMaxRows;
            if (maxScroll < 0) maxScroll = 0;
            if (_menuScroll > maxScroll) _menuScroll = maxScroll;

            RefreshMenuCountLabel();
        }

        /// <summary>
        /// Rebuilds the "rows 1-9 / 15" counter. Only for a list that does not fit: on a short
        /// list the number would be noise, and the absence of the counter is itself the message
        /// "this is the whole list".
        /// </summary>
        private void RefreshMenuCountLabel()
        {
            int visible = VisibleMenuRows;
            if (_menuRows.Count <= visible)
            {
                _menuCountLabel = null;
                return;
            }

            _menuCountLabel = string.Format(VgsText.ActionMenuRangeFormat,
                                            _menuScroll + 1, _menuScroll + visible, _menuRows.Count);
        }

        /// <summary>
        /// Action ids of the open menu, comma separated, for the diagnostic line in
        /// <see cref="OpenActionMenu"/>. Never called from the draw path.
        /// </summary>
        private static string JoinActionIds(List<Port> rows)
        {
            if (rows.Count == 0) return "-";

            var text = new System.Text.StringBuilder(rows.Count * 12);
            for (int i = 0; i < rows.Count; i++)
            {
                if (i > 0) text.Append(", ");
                text.Append(rows[i].Key);
            }
            return text.ToString();
        }

        private void CloseActionMenu()
        {
            _menuTarget = null;
            _menuMode = ActionMenuMode.None;
            _menuRows.Clear();
            _menuLabels.Clear();
            _menuTitle = null;
            _menuCountLabel = null;
            _menuHoverRow = -1;
            _menuScroll = 0;
        }

        private void ScrollMenu(int delta)
        {
            int maxScroll = _menuRows.Count - VgsConstants.ActionMenuMaxRows;
            if (maxScroll < 0) maxScroll = 0;

            _menuScroll += delta;
            if (_menuScroll > maxScroll) _menuScroll = maxScroll;
            if (_menuScroll < 0) _menuScroll = 0;

            RefreshMenuCountLabel();
        }

        /// <summary>
        /// Index of the action row under the pointer, or -1. Returns an index into
        /// <see cref="_menuRows"/> (already offset by the scroll position).
        /// </summary>
        private int MenuRowAt(Vector2 mouse)
        {
            if (_menuRows.Count == 0) return -1;

            Vector2 menuTopLeft, menuSize;
            GetMenuRect(out menuTopLeft, out menuSize);
            if (!PortGeometry.Contains(menuTopLeft, menuSize, mouse)) return -1;

            float local = mouse.Y - menuTopLeft.Y - VgsConstants.ActionMenuTitleHeight;
            if (local < 0f) return -1;

            int row = (int)(local / VgsConstants.ActionMenuRowHeight);
            if (row < 0 || row >= VisibleMenuRows) return -1;

            int index = row + _menuScroll;
            return index < _menuRows.Count ? index : -1;
        }

        /// <summary>
        /// Creates the connection the bind was aiming at.
        ///
        /// The order is deliberate: the item goes into the source block's real toolbar first,
        /// and only then into the graph. The toolbar is what makes the connection work
        /// (ADR-0011), so a graph edge without an item would be a line that does nothing. If
        /// the game refuses the placement — every page already holds that action, or the page
        /// list is full — the user is told why and nothing is changed.
        ///
        /// A group target is written as a group item, not as one item per member: that is the
        /// whole point of a group in this editor (ADR-0015). One cell, one item, and the game
        /// applies the action to every functional member when it fires. The two kinds share
        /// every step except the item itself, so they are branches of one method rather than
        /// two methods that would drift apart.
        ///
        /// Returns true only when the block really holds the connection afterwards. A click
        /// that could not be satisfied returns false, so the menu stays open and the user can
        /// pick another action instead of wondering whether the click registered.
        ///
        /// <b>False also covers the one outcome that is not a failure:</b> an action that takes
        /// arguments opens the dialog instead of writing, and the dialog — not this method — owns
        /// the rest of the gesture (ADR-0050). It closes the menu itself and keeps the bind armed,
        /// so the caller must do nothing in that case; that is why the answer is "was the
        /// connection written", which is exactly what the caller acts on.
        /// </summary>
        private bool TryCompleteBind(Port action)
        {
            Node source = _bindSource;
            Node target = _menuTarget;
            Port port = _bindPort;
            if (source == null || target == null || action == null || port == null) return false;

            // <b>An action that needs values is not written yet.</b> The item the game would run
            // stores those values inside itself, so writing it now would create a connection that
            // does something other than what the player asked for. The dialog opens instead, and
            // the write happens on confirm — which is also why Cancel costs nothing (ADR-0050).
            if (action.HasParameters)
            {
                BeginCreateParameters(source, port, target, action);

                // The menu closes, the bind stays armed: the player is now filling the request,
                // and Esc there returns them to the schema with the source still chosen.
                CloseActionMenu();
                return false;
            }

            IMyTerminalBlock sourceBlock = ResolveBlock(source.EntityId);
            if (sourceBlock == null)
            {
                Warn(VgsText.WarnBlockGone);
                return false;
            }

            ToolbarCell cell;
            ToolbarWriter.WriteResult result;
            bool toGroup = target.IsGroup;

            if (toGroup)
            {
                result = ToolbarWriter.TryWriteGroup(sourceBlock, source, port, target.GroupName,
                                                     action.Key, out cell);
            }
            else
            {
                IMyTerminalBlock targetBlock = ResolveBlock(target.EntityId);
                if (targetBlock == null)
                {
                    Warn(VgsText.WarnBlockGone);
                    return false;
                }

                result = ToolbarWriter.TryWrite(sourceBlock, source, port, targetBlock, action.Key, out cell);
            }

            if (result != ToolbarWriter.WriteResult.Ok)
            {
                Warn(DescribeWriteFailure(result, source, target, action));
                return false;
            }

            bool connected = toGroup
                ? _graph.TryConnectToGroup(source.EntityId, port.Key, target.GroupName, action.Key, cell)
                : _graph.TryConnect(source.EntityId, port.Key, target.EntityId, action.Key, cell);

            if (!connected)
            {
                // The graph refused an item the block now holds: put the cell back the way it
                // was rather than leaving wiring the editor does not show.
                VgsLog.Warn("bind rejected by graph: " + port.Key + " -> " + action.Key + " @ " + cell);
                ToolbarWriter.TryClear(sourceBlock, source, cell);
                Warn(VgsText.WarnRejected);
                return false;
            }

            // The new connection changes which port bars exist, so the stacks are recomputed.
            // A group's frame has to grow with its bars, so the frames follow.
            _graph.LayoutPorts();
            if (_graph.GroupCount > 0) PortGeometry.LayoutGroupFrames(_graph);

            VgsLog.Info("connected " + source.EntityId + " (" + port.Key + ") -> "
                        + (toGroup ? "group:" + target.GroupName : target.EntityId.ToString())
                        + " (" + action.Key + ") @ " + cell);
            return true;
        }

        /// <summary>
        /// Turns a write failure into the sentence the user sees. Each reason has its own
        /// wording because they call for different actions: a full toolbar needs a page freed,
        /// a duplicate needs a different target action, a vanished action needs a refresh.
        /// </summary>
        private static string DescribeWriteFailure(ToolbarWriter.WriteResult result, Node source,
                                                   Node target, Port action)
        {
            switch (result)
            {
                case ToolbarWriter.WriteResult.NotDrivable:
                    return string.Format(VgsText.WarnNotDrivableFormat, source.DisplayName);
                case ToolbarWriter.WriteResult.ActionOnEveryPage:
                    return string.Format(VgsText.WarnEveryPageFormat, action.DisplayName, source.DisplayName);
                case ToolbarWriter.WriteResult.NoFreeCell:
                    return string.Format(VgsText.WarnNoFreeCellFormat, source.DisplayName);
                case ToolbarWriter.WriteResult.ActionUnavailable:
                    return target.IsGroup
                        ? string.Format(VgsText.WarnGroupGoneFormat, target.GroupName)
                        : string.Format(VgsText.WarnActionGoneFormat, target.DisplayName, action.DisplayName);
                default:
                    return VgsText.WarnRejected;
            }
        }

        /// <summary>
        /// Removes every connection the given port carries, together with the items the source
        /// blocks hold in their toolbars.
        ///
        /// A port carries a set, not a single connection: an output may drive several targets
        /// (fan-out) and an input may be driven by several sources (fan-in). The button on the
        /// port therefore clears the whole set — that is what "delete this port's connections"
        /// means, and leaving some of them behind would keep the bar on screen after the click.
        ///
        /// <b>Order: toolbar first, graph second.</b> The toolbar is the connection (ADR-0011),
        /// and the refresh pass rebuilds edges from it. An edge dropped from the graph while its
        /// item stayed in the block would come back on the next refresh — the line would
        /// reappear under the user's cursor with no explanation. When the game refuses the clear
        /// (a remote client does not own the block's toolbar), that connection is kept and the
        /// user is told why, which is the same honesty the write path applies to a refused
        /// write.
        ///
        /// A destroyed block needs no clearing: its toolbar went with it, and the stale edge is
        /// dropped from the graph here.
        ///
        /// The other end of each connection needs no special handling:
        /// <see cref="GridGraph.LayoutPorts"/> gives a port a drawing slot only while it carries
        /// at least one edge, so a port that has just lost its last connection — the source's
        /// output or the target's input — disappears by itself.
        /// </summary>
        private void RemovePortConnections(Node node, Port port)
        {
            if (node == null || port == null) return;

            _removeBuffer.Clear();
            _graph.CollectEdgesForPort(node, port.Key, port.Direction, _removeBuffer);
            if (_removeBuffer.Count == 0) return;

            int removed = 0;
            int changedUnderEditor = 0;
            long warnedAbout = 0;

            for (int i = 0; i < _removeBuffer.Count; i++)
            {
                Edge edge = _removeBuffer[i];

                Node source = _graph.GetNode(edge.SourceEntityId);
                IMyTerminalBlock sourceBlock = ResolveBlock(edge.SourceEntityId);

                // Only a cell that really holds this connection needs clearing. An edge without a
                // valid cell cannot be expressed in a toolbar at all (TryConnect refuses one), so
                // it is dropped without a warning rather than kept forever as an undeletable line.
                if (edge.Cell.IsValid && sourceBlock != null && source != null)
                {
                    CellState state = ReadCellState(sourceBlock, edge);

                    // The cell no longer holds this connection: it is empty, or the player
                    // replaced it by hand in the terminal during the up-to-one-refresh window when
                    // the graph lags the world. Either way it is not ours to clear, so it is left
                    // alone; the reconcile pass then turns whatever is there now into its own edge.
                    if (state == CellState.HoldsOther)
                    {
                        changedUnderEditor++;
                        if (_graph.RemoveEdge(edge)) removed++;
                        continue;
                    }

                    // HoldsThis is the only state that may be cleared. Unreadable is NOT "safe to
                    // clear": the player's edit cannot be ruled out, so the connection is kept and
                    // the reason is shown — the same answer as a refused clear. Dropping the edge
                    // here would make the line reappear at the next reconcile pass with no
                    // explanation, which is the defect this whole method exists to avoid.
                    if (state != CellState.HoldsThis
                        || !ToolbarWriter.TryClear(sourceBlock, source, edge.Cell))
                    {
                        WarnRemoveRefused(source, ref warnedAbout);
                        continue;
                    }
                }

                if (_graph.RemoveEdge(edge)) removed++;
            }

            _removeBuffer.Clear();
            _hoverRemoveNode = null;
            _hoverRemovePort = null;

            // The stacks are a derived view of the edges: the port that just lost its last
            // connection must lose its bar, and the stack under it must close up.
            _graph.LayoutPorts();
            if (_graph.GroupCount > 0) PortGeometry.LayoutGroupFrames(_graph);

            if (changedUnderEditor > 0)
            {
                VgsLog.Info(changedUnderEditor + " cell(s) no longer held their connection and were "
                            + "left untouched; the reconcile pass re-reads them");
            }

            if (removed > 0)
            {
                VgsLog.Info("removed " + removed + " connection(s) at " + node.EntityId
                            + " (" + port.Key + ")");
            }
        }

        /// <summary>
        /// What a connection's toolbar cell currently holds, as far as the editor can tell.
        ///
        /// Three outcomes, and they must not be collapsed into a bool: the caller's answer to
        /// "holds this connection" is *clear the cell*, its answer to "holds something else" is
        /// *leave it alone*, and its answer to "cannot tell" is *do nothing and say so*. A bool
        /// would make the third indistinguishable from the second and the removal would silently
        /// do nothing (the line then reappears at the next reconcile pass).
        /// </summary>
        private enum CellState
        {
            /// <summary>The cell holds exactly this connection: safe to clear.</summary>
            HoldsThis = 0,

            /// <summary>
            /// The cell no longer holds this connection: it is empty, or it holds another item.
            /// Either way it is not ours to clear — an empty cell has nothing to clear, and the
            /// other item is the player's edit.
            /// </summary>
            HoldsOther = 1,

            /// <summary>The toolbar could not be read. Neither clearing nor dropping is safe.</summary>
            Unreadable = 2
        }

        /// <summary>
        /// Reads the cell this edge occupies and reports which of the three cases it is: the same
        /// target block and action, a different item, or nothing readable.
        ///
        /// A read, not a write, so it is safe on a remote client too — which is the point: the
        /// check is what stops a removal from destroying an edit the player made in the terminal
        /// during the up-to-one-refresh window when the graph is behind the world.
        /// </summary>
        private static CellState ReadCellState(IMyTerminalBlock sourceBlock, Edge edge)
        {
            try
            {
                IMyToolbar toolbar = ToolbarProbe.GetToolbar(sourceBlock, edge.Cell.ToolbarIndex);
                if (toolbar == null) return CellState.Unreadable;

                CellContents contents = ToolbarWriter.TryDescribe(toolbar, edge.Cell.Index);
                if (contents.IsEmpty) return CellState.HoldsOther;

                bool holdsThis = ToolbarParameters.SameItem(contents, edge);

                return holdsThis ? CellState.HoldsThis : CellState.HoldsOther;
            }
            catch (Exception e)
            {
                VgsLog.Throttled("cell-state", "could not read toolbar cell", e, 300);
                return CellState.Unreadable;
            }
        }

        /// <summary>
        /// Reports that a connection could not be removed from its block's toolbar, once per
        /// source block.
        ///
        /// Once, because a fan-in of three connections from the same block would otherwise queue
        /// the same sentence three times into one bottom bar, which shows only the last copy — the
        /// user would see one message and no indication that three attempts were made.
        /// <paramref name="warnedAbout"/> is the caller's running record, so the deduplication
        /// survives the loop without the caller keeping a set.
        /// </summary>
        private void WarnRemoveRefused(Node source, ref long warnedAbout)
        {
            if (source == null) return;
            if (warnedAbout == source.EntityId) return;

            warnedAbout = source.EntityId;
            Warn(string.Format(VgsText.WarnRemoveRefusedFormat, source.DisplayName));
        }

        /// <summary>Shows a failure on the bottom bar and records it in the log.</summary>
        private void Warn(string text)
        {
            _warningText = text;
            _warningUntilFrame = _screenFrame + VgsConstants.WarningFrames;
            VgsLog.Warn(text);
        }

        /// <summary>
        /// Resolves a node back to its live block. The entity id can be stale — the block may
        /// have been destroyed since the last refresh — so the result is checked, never assumed.
        ///
        /// Shorthand for the call sites below; the lookup itself is
        /// <see cref="EntityResolver.TryResolveTerminalBlock"/>, the one implementation of
        /// "entity id → block" in the mod (it carries the try/catch and the log tag).
        /// </summary>
        private static IMyTerminalBlock ResolveBlock(long entityId)
        {
            IMyTerminalBlock block;
            return EntityResolver.TryResolveTerminalBlock(entityId, out block) ? block : null;
        }

        // ------------------------------------------------------------------ hit testing

        /// <summary>Converts a normalized screen point to graph space.</summary>
        private Vector2 ScreenToGraph(Vector2 screenPoint, Vector2 canvasTopLeft)
        {
            return (screenPoint - canvasTopLeft) / _view.Zoom + _view.Camera;
        }

        /// <summary>Converts a graph-space point to normalized screen space.</summary>
        private Vector2 GraphToScreen(Vector2 graphPoint, Vector2 canvasTopLeft)
        {
            return (graphPoint - _view.Camera) * _view.Zoom + canvasTopLeft;
        }

        /// <summary>
        /// Topmost node under a graph-space point, or null. Ports count as the node.
        ///
        /// Blocks are tested before groups: the frame of a group surrounds its members, so a
        /// click on a card must select the card and not the group that contains it. Groups are
        /// only hit through their title strip and their port bars
        /// (<see cref="PortGeometry.HitNode"/>), which is what makes that ordering sufficient.
        /// </summary>
        private Node HitTest(Vector2 graphPoint)
        {
            IList<Node> nodes = _graph.Nodes;
            // Iterate backwards so the visually topmost (last drawn) node wins.
            for (int i = nodes.Count - 1; i >= 0; i--)
            {
                if (PortGeometry.HitNode(nodes[i], graphPoint)) return nodes[i];
            }

            IList<Node> groups = _graph.Groups;
            for (int i = groups.Count - 1; i >= 0; i--)
            {
                if (PortGeometry.HitNode(groups[i], graphPoint)) return groups[i];
            }
            return null;
        }

        /// <summary>
        /// Topmost node whose card button row is under the pointer, and which of its buttons.
        ///
        /// One test for the whole row, because the row is one control group (ADR-0020): the jump
        /// button, the watch button, the yes/no pair and the single bind button differ only in
        /// what they do, so resolving them separately would mean five loops over the same nodes
        /// and an ordering question between them.
        /// </summary>
        private Node HitTestCardButton(Vector2 graphPoint, out CardButtonKind kind)
        {
            kind = CardButtonKind.Jump;
            float aspect = VgsScreenDraw.ClientAspect;
            IList<Node> nodes = _graph.Nodes;
            for (int i = nodes.Count - 1; i >= 0; i--)
            {
                CardButtonKind hit;
                if (PortGeometry.HitCardButton(nodes[i], graphPoint, aspect, out hit))
                {
                    kind = hit;
                    return nodes[i];
                }
            }
            return null;
        }

        /// <summary>Topmost controller whose watch port carries the "x" under the pointer.</summary>
        private Node HitTestWatchRemoveButton(Vector2 graphPoint, out WatchTarget watch)
        {
            watch = null;
            float aspect = VgsScreenDraw.ClientAspect;

            IList<Node> nodes = _graph.Nodes;
            for (int i = nodes.Count - 1; i >= 0; i--)
            {
                WatchTarget hit = PortGeometry.HitWatchRemoveButton(nodes[i], graphPoint, aspect);
                if (hit == null) continue;
                watch = hit;
                return nodes[i];
            }
            return null;
        }

        /// <summary>
        /// Topmost node whose <b>remove</b> button is under the pointer, together with what that
        /// button belongs to: an event port, or an input bar (ADR-0050).
        ///
        /// <b>Two answers, one question.</b> An event port is one bar and its "x" deletes the
        /// port's connections; an input bar is one *request* and its "x" deletes only that
        /// request. Both are the same kind of target for the pointer, so they are resolved
        /// together — a separate pass would let the two overlap and the later one win.
        /// </summary>
        private Node HitTestRemoveButton(Vector2 graphPoint, out Port port, out InputBar bar)
        {
            port = null;
            bar = null;
            float aspect = VgsScreenDraw.ClientAspect;

            // Blocks first, for the same reason as in HitTest: a group's frame contains its
            // members, and a member's own remove button is the more specific target.
            IList<Node> nodes = _graph.Nodes;
            for (int i = nodes.Count - 1; i >= 0; i--)
            {
                Node node = nodes[i];

                Port hit = PortGeometry.HitPortRemoveButton(node, graphPoint, aspect);
                if (hit != null)
                {
                    port = hit;
                    return node;
                }

                InputBar barHit = PortGeometry.HitInputBarRemoveButton(node, graphPoint, aspect);
                if (barHit != null)
                {
                    bar = barHit;
                    return node;
                }
            }

            IList<Node> groups = _graph.Groups;
            for (int i = groups.Count - 1; i >= 0; i--)
            {
                Node group = groups[i];

                Port hit = PortGeometry.HitPortRemoveButton(group, graphPoint, aspect);
                if (hit != null)
                {
                    port = hit;
                    return group;
                }

                // A group has input bars only, and they are the only "x" it can carry.
                InputBar barHit = PortGeometry.HitInputBarRemoveButton(group, graphPoint, aspect);
                if (barHit != null)
                {
                    bar = barHit;
                    return group;
                }
            }
            return null;
        }

        /// <summary>
        /// Topmost node whose input bar carries the <b>edit</b> button under the pointer, and
        /// which bar (ADR-0050).
        /// </summary>
        private Node HitTestEditButton(Vector2 graphPoint, out InputBar bar)
        {
            bar = null;
            float aspect = VgsScreenDraw.ClientAspect;

            IList<Node> nodes = _graph.Nodes;
            for (int i = nodes.Count - 1; i >= 0; i--)
            {
                InputBar hit = PortGeometry.HitInputBarEditButton(nodes[i], graphPoint, aspect);
                if (hit == null) continue;
                bar = hit;
                return nodes[i];
            }

            IList<Node> groups = _graph.Groups;
            for (int i = groups.Count - 1; i >= 0; i--)
            {
                InputBar hit = PortGeometry.HitInputBarEditButton(groups[i], graphPoint, aspect);
                if (hit == null) continue;
                bar = hit;
                return groups[i];
            }
            return null;
        }

        /// <summary>
        /// Refreshes the hover targets used for the highlight of a card, of the buttons on it and
        /// of the remove button on one of its ports.
        ///
        /// Hover is recomputed from the pointer every input pass rather than cached until a
        /// move event: the canvas pans and zooms under a still pointer, so "under the pointer"
        /// changes without the pointer moving.
        /// </summary>
        private void UpdateHover(Vector2 mouse, Vector2 canvasTopLeft, Vector2 canvasSize)
        {
            ClearHoverTargets();

            if (!PortGeometry.Contains(canvasTopLeft, canvasSize, mouse)) return;

            Vector2 graphPos = ScreenToGraph(mouse, canvasTopLeft);

            // The remove button is the smallest target on the canvas, and it is drawn on top of
            // a bar that belongs to the card. Resolving it first is what makes the highlight
            // land on the disc instead of on the whole port.
            Port removePort;
            InputBar removeBar;
            Node removeNode = HitTestRemoveButton(graphPos, out removePort, out removeBar);
            if (removeNode != null)
            {
                _hoverRemoveNode = removeNode;
                _hoverRemovePort = removePort;
                _hoverRemoveBar = removeBar;
                return;
            }

            // The edit button is the same kind of target as the "x" beside it, and it is
            // resolved right after it so the two cannot both claim the pointer (ADR-0050).
            InputBar editBar;
            Node editNode = HitTestEditButton(graphPos, out editBar);
            if (editNode != null)
            {
                _hoverEditNode = editNode;
                _hoverEditBar = editBar;
                return;
            }

            // A watch port's "x" is the same kind of target (ADR-0017).
            WatchTarget watchRemove;
            Node watchRemoveNode = HitTestWatchRemoveButton(graphPos, out watchRemove);
            if (watchRemoveNode != null)
            {
                _hoverWatchRemoveNode = watchRemoveNode;
                _hoverWatchRemoveTarget = watchRemove;
                return;
            }

            // The card's button row before the card: a button sits on the card, and a card
            // highlight under a button would suggest a drag where a click starts a gesture.
            CardButtonKind kind;
            _hoverButton = HitTestCardButton(graphPos, out kind);
            _hoverButtonKind = kind;

            // The power switch is a control too, and it lives in the card's state column — the same
            // rule: it highlights instead of the card, because a click there switches the block
            // rather than grabbing it (ADR-0035).
            _hoverPowerSwitch = HitTestPowerSwitch(graphPos);

            // A card under a control is not "hovered": the control is the thing about to be
            // clicked, and highlighting the card as well would suggest a drag.
            _hoverNode = _hoverButton == null && _hoverPowerSwitch == null ? HitTest(graphPos) : null;

            // ---- the line under the pointer (ADR-0049) ----
            //
            // Resolved last, and only when nothing else is under the pointer: a line is drawn
            // under the cards and under every control, so a pointer that is over a card, a port
            // bar, a button or a switch is not over a line — even when the line runs underneath
            // it. The reverse order would make a wire crossing a card steal the card's own hover.
            if (_hoverNode == null && _hoverButton == null && _hoverPowerSwitch == null)
            {
                UpdateHoveredLine(mouse, canvasTopLeft);
            }
        }

        // ------------------------------------------------------------------ line hover (ADR-0049)

        /// <summary>
        /// Finds the line under the pointer and remembers it: a connection, a watch link or a
        /// pipe, whichever is drawn on top at that point.
        ///
        /// <b>Topmost wins, in the draw order reversed.</b> The canvas is painted pipes, then
        /// connections, then watch links (<see cref="OnDraw"/>), so a pointer that lands on a
        /// crossing is over the watch link. Each test walks its own list and keeps the
        /// <em>last</em> match, because a later line in a list is painted over an earlier one.
        ///
        /// <b>The tolerance is in device pixels</b> (<see cref="VgsConstants.LineHoverPixels"/>):
        /// the layout's axes do not share a scale (ADR-0009), so a tolerance in layout units would
        /// be a wider band on one axis than on the other and would thin out as the player zoomed.
        /// <see cref="LineHit"/> does the per-axis conversion.
        ///
        /// Nothing is measured when the client area has not been read yet: every length would be
        /// zero and every line would be "under the pointer".
        /// </summary>
        private void UpdateHoveredLine(Vector2 mouse, Vector2 canvasTopLeft)
        {
            Vector2 pixelsPerUnit = new Vector2(VgsScreenDraw.ClientWidth, VgsScreenDraw.ClientHeight);
            if (pixelsPerUnit.X <= 0f || pixelsPerUnit.Y <= 0f) return;

            float tolerance = VgsConstants.LineHoverPixels;

            if (TryHitWatchLine(mouse, canvasTopLeft, pixelsPerUnit, tolerance)) return;
            if (TryHitEdge(mouse, canvasTopLeft, pixelsPerUnit, tolerance)) return;

            TryHitConveyor(mouse, canvasTopLeft, pixelsPerUnit, tolerance);
        }

        /// <summary>
        /// Looks for a watch link under the pointer. Returns true when one was found, and leaves
        /// <see cref="_hoverWatchController"/> and <see cref="_hoverWatchTarget"/> naming it.
        ///
        /// The walk is the draw pass's walk — the same nodes, the same slots, the same cap — so a
        /// line the player can see is a line the pointer can catch, and a watch bar without a line
        /// (a controller watching itself, ADR-0036) is not a target.
        /// </summary>
        private bool TryHitWatchLine(Vector2 mouse, Vector2 canvasTopLeft, Vector2 pixelsPerUnit,
                                     float tolerance)
        {
            IList<Node> nodes = _graph.Nodes;

            Node hitController = null;
            WatchTarget hitTarget = null;
            int drawn = 0;

            for (int i = 0; i < nodes.Count && drawn < VgsConstants.MaxRenderedEdges; i++)
            {
                Node controller = nodes[i];
                if (controller.Controller == null) continue;

                List<WatchTarget> watched = controller.Controller.Watched;
                for (int w = 0; w < watched.Count && drawn < VgsConstants.MaxRenderedEdges; w++)
                {
                    WatchTarget watch = watched[w];
                    if (watch.Slot < 0) continue;

                    Node target;
                    if (!TryBuildWatchRoute(controller, watch, canvasTopLeft, out target)) continue;

                    drawn++;

                    if (!LineHit.RouteBoundsReach(_route, mouse, pixelsPerUnit, tolerance)) continue;
                    if (!LineHit.IsWithin(RoundedPath(), mouse, pixelsPerUnit, tolerance)) continue;

                    hitController = controller;
                    hitTarget = watch;
                }
            }

            _hoverWatchController = hitController;
            _hoverWatchTarget = hitTarget;
            return hitController != null;
        }

        /// <summary>
        /// Looks for a connection under the pointer. Returns true when one was found and leaves it
        /// in <see cref="_hoverEdge"/>.
        ///
        /// It walks <see cref="GridGraph.Lines"/> — the de-duplicated list the draw pass walks —
        /// so the two passes agree about which connections have a line at all.
        /// </summary>
        private bool TryHitEdge(Vector2 mouse, Vector2 canvasTopLeft, Vector2 pixelsPerUnit,
                                float tolerance)
        {
            IList<Edge> lines = _graph.Lines;

            Edge hit = null;
            int drawn = 0;

            for (int i = 0; i < lines.Count && drawn < VgsConstants.MaxRenderedEdges; i++)
            {
                Node source, target;
                if (!TryBuildEdgeRoute(lines[i], canvasTopLeft, out source, out target)) continue;

                drawn++;

                if (!LineHit.RouteBoundsReach(_route, mouse, pixelsPerUnit, tolerance)) continue;
                if (!LineHit.IsWithin(RoundedPath(), mouse, pixelsPerUnit, tolerance)) continue;

                hit = lines[i];
            }

            _hoverEdge = hit;
            return hit != null;
        }

        /// <summary>
        /// Looks for a conveyor pipe under the pointer. Returns true when one was found and leaves
        /// it in <see cref="_hoverConveyor"/>.
        ///
        /// <b>The pipe is measured against its route, not against its rails.</b> Its bends are a
        /// staircase around the route's corner, a couple of pixels away at most, which is smaller
        /// than the slack the pointer is given — and the route is what both passes already have.
        ///
        /// <b>The tolerance is measured from the pipe's edge, not its centre.</b> A pipe is six
        /// pixels wide, so half of that is added: the pointer gets the same slack around the pipe
        /// as it gets around a two-pixel line, and the pipe does not become a fatter target for
        /// being fatter.
        /// </summary>
        private bool TryHitConveyor(Vector2 mouse, Vector2 canvasTopLeft, Vector2 pixelsPerUnit,
                                    float tolerance)
        {
            if (!_view.ShowConveyors) return false;

            IList<ConveyorLink> links = _graph.Conveyors;
            if (links.Count == 0) return false;

            float pipeTolerance = tolerance + VgsConstants.ConveyorFillPixels * 0.5f;

            ConveyorLink hit = null;
            int drawn = 0;

            for (int i = 0; i < links.Count && drawn < VgsConstants.MaxRenderedConveyors; i++)
            {
                Node source, target;
                if (!TryBuildConveyorRoute(links[i], canvasTopLeft, out source, out target)) continue;

                drawn++;

                if (!LineHit.RouteWithin(_route, mouse, pixelsPerUnit, pipeTolerance)) continue;

                hit = links[i];
            }

            _hoverConveyor = hit;
            return hit != null;
        }

        /// <summary>
        /// The rounded path of the route in <see cref="_route"/>, as the draw pass draws it.
        ///
        /// <b>A hit test on the route would be a hit test on a line nobody sees.</b> A connection
        /// is drawn as the rounded path — the corners are cut from the middle of one segment to
        /// the middle of the next (ADR-0046) — so near a bend the route and the line are up to
        /// half a segment apart. The pointer is measured against what is painted.
        ///
        /// The path is left in <see cref="_path"/>; both scratch buffers belong to the screen and
        /// are rebuilt by every pass that uses them, so the input pass may fill them exactly as the
        /// draw pass does.
        /// </summary>
        private List<Vector2> RoundedPath()
        {
            EdgeRouting.Round(_route, PixelsPerUnit, _path);
            return _path;
        }
    }
}





